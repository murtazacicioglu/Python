### `preprocessor.py`:

- Regex için ChatGPT, test için https://regexr.com & https://regex101.com
- Çevrim içi yorumlayıcı https://online-python.com
