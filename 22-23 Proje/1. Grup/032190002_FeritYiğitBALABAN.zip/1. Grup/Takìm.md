## 1. Grup

- İrem İÇÖZ <[irem0](https://github.com/irem0)>
- Damla SOYDAN <[damlas21](https://github.com/damlas21)>
- Ferit Yiğit BALABAN <[fybx](https://github.com/fybx)>
- Sabir SÜLEYMANLI <[sabir-suleyman](https://github.com/sabir-suleyman)>
- Zeynep KILINÇER <[zkilincer](https://github.com/zkilincer)>

**Proje Konusu:** Sanallaştırılmış Mikroişlemci Yorumlama Ortamı
