from atexit import register
import html
from django.contrib import admin
from .models import Kitap,Kategori
from django.utils.safestring import mark_safe

class KitapAdmin(admin.ModelAdmin):
    list_display = ("name", "author", "is_main", "slug", "selected_categories",)
    list_editable= ("is_main",)
    search_fields= ("name", "description",)
    readonly_fields= ("slug",)
    list_filter= ("is_main", "categories",)

    def selected_categories(self, obj):
        html = "<ul>"
        for cat in obj.categories.all():
            html+= "<li>" + cat.name + "</li>"
        html+="</ul>"
        return mark_safe(html)

class KategoriAdmin(admin.ModelAdmin):
    list_display = ("name", "slug")
    readonly_fields= ("slug",)
    search_fields= ("name",)


admin.site.register(Kitap, KitapAdmin)
admin.site.register(Kategori, KategoriAdmin)