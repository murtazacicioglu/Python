from xml.dom.minidom import Document
from  django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import Settings, settings
#   http://127.0.0.1:8000/
#   http://127.0.0.1:8000/index
#   http://127.0.0.1:8000/Kütüphane
#   http://127.0.0.1:8000/Kitapp

urlpatterns = [

    path("", views.homepage, name="home"),
    path("anasayfa", views.homepage),
    path("hakkımızda",views.Hakkimizda, name="about"),   
    path("kutuphane",views.library, name="lib"),   
    path("kutuphane/<slug:slug>",views.library_details, name="lib_details"),   
    path("kategori/<slug:slug>",views.books_by_category, name="cate_details"),   
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) \
  + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
