from os import name
from statistics import mode
from unicodedata import category
from django.db import models
from django.utils.text import slugify
from ckeditor.fields import RichTextField
from django.contrib.auth.models import User

class Kategori(models.Model):
    name  = models.CharField(max_length=150)
    slug = models.SlugField(null=False, blank=True, unique=True, db_index=True, editable=False)
    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        self.slug = slugify(self.name)
        return super().save(*args, **kwargs)

class Kitap(models.Model):
    name  = models.CharField(max_length=150)
    image  = models.ImageField(upload_to="books")
    is_main   = models.BooleanField(default=False)
    author  = models.CharField(max_length=50)
    description = RichTextField()
    slug = models.SlugField(null=False, blank=True, unique=True, db_index=True, editable=False)
    categories = models.ManyToManyField(Kategori, blank=True)

    def __str__(self):
        return f"{self.name}"
    
    def save(self, *args, **kwargs):
        self.slug = slugify(self.name)
        return super().save(*args, **kwargs)
    
class Yorum(models.Model):
    fWho = models.ForeignKey(User, on_delete=models.CASCADE)
    tWhere = models.ForeignKey(Kitap, on_delete=models.CASCADE)
    comment = RichTextField()

    def __str__(self):
        return f"{self.fWho}|{self.tWhere}"