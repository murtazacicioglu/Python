from cgitb import text
from multiprocessing import context
from os import name
from re import search
import select
from unicodedata import category
from django.shortcuts import render
from django.http.response import HttpResponse
from kutuphane.models import Kategori, Kitap, Yorum
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.models import User



def homepage(request):

    return render(request, "lib/index.html")

def Hakkimizda(request):

    return render(request, "lib/hakkimizda.html")

def library(request):
    if request.method == "POST":
        searched = request.POST['searched']
        request.session['search'] = searched
        context = { "books" : Kitap.objects.filter(name__contains=searched),
                    "categories" : Kategori.objects.all(),
        }
    else:    
        context = { "books" : Kitap.objects.filter(is_main=True),
                    "categories" : Kategori.objects.all(),
        }

    return render(request, "lib/lib.html", context)

def books_by_category(request, slug):
    if request.method == "POST":
        searched = request.POST['searched']
        request.session['search'] = searched
        context = { "books" : Kitap.objects.filter(name__contains=searched, categories__slug=slug),
                    "categories" : Kategori.objects.all(),
                    "selectedCate" : slug
        }
    else:    
        context = { "books" : Kitap.objects.filter(is_main=True, categories__slug=slug),
                    "categories" : Kategori.objects.all(),
                    "selectedCate" : slug
        }

    return render(request, "lib/lib.html", context)

def library_details(request,slug):
    book = Kitap.objects.get(slug=slug)
    if request.method == "POST":
        text = request.POST['commenttext']
        y = Yorum(fWho=request.user, tWhere=book, comment=text)  
        y.save()  
    category = Kategori.objects.all()
    comments = Yorum.objects.filter(tWhere=book).order_by('-id')
    str1 = ""
    for cate in book.categories.all():
        str1+=str(cate).title()+", "
    if str1=="":
        str1="<i>Kategorisi yok...</i>"
    return render(request, "lib/lib_details.html", {"book":book, "categories" : category, "comments":comments, "string":str1,})
# Create your views here.
