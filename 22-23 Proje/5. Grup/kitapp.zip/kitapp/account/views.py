from multiprocessing import AuthenticationError
from kutuphane.models import Kategori, Kitap, Yorum
from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User

# Create your views here.

def login_(request):
    if request.user.is_authenticated:
        return redirect("home")
    if request.method=="POST":
        username=request.POST["username"]
        password=request.POST["password"]
        user = authenticate(request, username = username, password = password)
        if user is not None:
            login(request, user)
            return redirect("home")
        else:
            return render(request, "account/login.html",{
                "error": "kullanıcı adı veya şifre yanlış",
                "username":username})
    return render(request, "account/login.html")

def register_(request):
    if request.user.is_authenticated:
        return redirect("home")
    if request.method=="POST":
        username=request.POST["username"]
        email=request.POST["email"]
        firstname=request.POST["firstname"]
        lastname=request.POST["lastname"]
        password=request.POST["password"]
        repassword=request.POST["repassword"]
        if password==repassword:
            if User.objects.filter(username=username).exists():
                return render(request, "account/register.html",{
                "error": "Bu kullanıcı adı halihazırda kullanılıyor",
                "username":username,
                "email":email,
                "firstname":firstname,
                "lastname":lastname,
                })
            else:
                if User.objects.filter(email=email).exists():
                    return render(request, "account/register.html",{
                    "error": "Bu mail halihazırda kullanılıyor",
                    "username":username,
                    "email":email,
                    "firstname":firstname,
                    "lastname":lastname,})
                else:
                    user = User.objects.create_user(username=username, email=email, first_name=firstname, last_name=lastname, password=password)
                    user.save()
                    return redirect("log")
        else:
            return render(request, "account/register.html",{
                "error": "Tutarsız şifre yazdınız",
                "username":username,
                "email":email,
                "firstname":firstname,
                "lastname":lastname,
            })
    return render(request, "account/register.html")

def profile(request):
    if not request.user.is_authenticated:
        return redirect("home")
    comments = Yorum.objects.filter(fWho=request.user).order_by('-id')
    return render(request, "account/profile.html", { "comments":comments })

def exit(request):
    if not request.user.is_authenticated:
        return redirect("home")
    logout(request)
    return redirect("home")

def mobileLogin(request):
    if request.user.is_authenticated:
        return redirect("home")
    if request.method=="POST":
        username=request.POST["username"]
        password=request.POST["password"]
        user = authenticate(request, username = username, password = password)
        if user is not None:
            return redirect("home")
        else:
            return render(request, "account/mobileLogin.html",{
                "error": "kullanıcı adı veya şifre yanlış",
                "username":username})
    return render(request, "account/mobileLogin.html")

def mobileComment(request,slug):
    if request.user.is_authenticated:
        return redirect("home")
    book = Kitap.objects.get(slug=slug)
    if request.method=="POST":
        username=request.POST["username"]
        password=request.POST["password"]
        commenttext=request.POST["comment"]
        user = authenticate(request, username = username, password = password)
        if user is not None:
            y = Yorum(fWho=user, tWhere=book, comment=commenttext)
            y.save()
            return redirect("home")
        else:
            return render(request, "account/mobileComment.html",{
                "error": "kullanıcı adı veya şifre yanlış",
                "username":username})
    return render(request, "account/mobileComment.html")